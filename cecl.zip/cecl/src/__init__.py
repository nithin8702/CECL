def demo():
    return 'hello world!'